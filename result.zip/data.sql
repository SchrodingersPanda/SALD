-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB-0+deb9u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dbo.Adulto`
--

DROP TABLE IF EXISTS `dbo.Adulto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.Adulto` (
  `ID` varchar(10) DEFAULT NULL,
  `Nombre` varchar(7) DEFAULT NULL,
  `Apellido` varchar(8) DEFAULT NULL,
  `Telefono` bigint(20) DEFAULT NULL,
  `Email` varchar(14) DEFAULT NULL,
  `AlumnoID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.Adulto`
--

LOCK TABLES `dbo.Adulto` WRITE;
/*!40000 ALTER TABLE `dbo.Adulto` DISABLE KEYS */;
INSERT INTO `dbo.Adulto` VALUES ('44444444-4','Javier','Suarez',56912345678,'correo@mail.cl','77777777-7'),('55555555-5','Rosario','Valdivia',56912345678,'correo@mail.cl','88888888-8'),('66666666-6','Alfonso','Suarez',56912345678,'correo@mail.cl','99999999-9');
/*!40000 ALTER TABLE `dbo.Adulto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.Alumno`
--

DROP TABLE IF EXISTS `dbo.Alumno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.Alumno` (
  `ID` varchar(10) DEFAULT NULL,
  `Nombre` varchar(5) DEFAULT NULL,
  `Apellido` varchar(8) DEFAULT NULL,
  `FechaNAc` varchar(19) DEFAULT NULL,
  `HojaVida` varchar(12) DEFAULT NULL,
  `AdultoID` varchar(12) DEFAULT NULL,
  `NivelID` varchar(11) DEFAULT NULL,
  `Salas_ID` varchar(0) DEFAULT NULL,
  `Usuario_ID` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.Alumno`
--

LOCK TABLES `dbo.Alumno` WRITE;
/*!40000 ALTER TABLE `dbo.Alumno` DISABLE KEYS */;
INSERT INTO `dbo.Alumno` VALUES ('77777777-7','Ines','Suarez','2018-09-01 00:00:00','Sin novdedad','44.444.444-4','SCMY-2019-1','',''),('88888888-8','Pedro','Valdivia','2016-09-01 00:00:00','Sin novdedad','55.555.555-5','MMY-2019-2','',''),('99999999-9','Diego','Almagro','2014-09-01 00:00:00','Sin novdedad','66.666.666-6','KDR-2019-3','','');
/*!40000 ALTER TABLE `dbo.Alumno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.Bitacora`
--

DROP TABLE IF EXISTS `dbo.Bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.Bitacora` (
  `ID` varchar(0) DEFAULT NULL,
  `Novedades` varchar(0) DEFAULT NULL,
  `SalaID` varchar(0) DEFAULT NULL,
  `PlanificacionID` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.Bitacora`
--

LOCK TABLES `dbo.Bitacora` WRITE;
/*!40000 ALTER TABLE `dbo.Bitacora` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo.Bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.Nivel`
--

DROP TABLE IF EXISTS `dbo.Nivel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.Nivel` (
  `ID` varchar(11) DEFAULT NULL,
  `Nombre` tinyint(4) DEFAULT NULL,
  `RangoEdad` tinyint(4) DEFAULT NULL,
  `CantAlumnos` tinyint(4) DEFAULT NULL,
  `Año` smallint(6) DEFAULT NULL,
  `Periodo` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.Nivel`
--

LOCK TABLES `dbo.Nivel` WRITE;
/*!40000 ALTER TABLE `dbo.Nivel` DISABLE KEYS */;
INSERT INTO `dbo.Nivel` VALUES ('KDR-2019-3',5,5,10,2019,2),('MMY-2019-2',3,3,10,2019,1),('SCMY-2019-1',1,1,10,2019,0);
/*!40000 ALTER TABLE `dbo.Nivel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.Planificacion`
--

DROP TABLE IF EXISTS `dbo.Planificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.Planificacion` (
  `ID` varchar(0) DEFAULT NULL,
  `Inicio` varchar(0) DEFAULT NULL,
  `Termino` varchar(0) DEFAULT NULL,
  `Encargado` varchar(0) DEFAULT NULL,
  `Objetivos_prop` varchar(0) DEFAULT NULL,
  `Objetivos_cump` varchar(0) DEFAULT NULL,
  `Actividades_prop` varchar(0) DEFAULT NULL,
  `Actividades_cump` varchar(0) DEFAULT NULL,
  `NivelID` varchar(0) DEFAULT NULL,
  `SalaID` varchar(0) DEFAULT NULL,
  `NumeroR` varchar(0) DEFAULT NULL,
  `Novedades` varchar(0) DEFAULT NULL,
  `ListaAp` varchar(0) DEFAULT NULL,
  `UsuarioID` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.Planificacion`
--

LOCK TABLES `dbo.Planificacion` WRITE;
/*!40000 ALTER TABLE `dbo.Planificacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo.Planificacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.Sala`
--

DROP TABLE IF EXISTS `dbo.Sala`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.Sala` (
  `ID` varchar(4) DEFAULT NULL,
  `Horario` tinyint(4) DEFAULT NULL,
  `NivelID` varchar(11) DEFAULT NULL,
  `Ast` varchar(15) DEFAULT NULL,
  `Educ` varchar(16) DEFAULT NULL,
  `Planificacion_ID` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.Sala`
--

LOCK TABLES `dbo.Sala` WRITE;
/*!40000 ALTER TABLE `dbo.Sala` DISABLE KEYS */;
INSERT INTO `dbo.Sala` VALUES ('S-01',0,'SCMY-2019-1','Evelyn Aravena','Natalia Garrido',''),('S-02',2,'MMY-2019-2','Maricel Ortega','Carolina Moya',''),('S-03',3,'KDR-2019-3','Barbara Vasquez','Marcela Martinez','');
/*!40000 ALTER TABLE `dbo.Sala` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.Usuario`
--

DROP TABLE IF EXISTS `dbo.Usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.Usuario` (
  `ID` varchar(10) DEFAULT NULL,
  `Nombre` varchar(9) DEFAULT NULL,
  `Apellido` varchar(6) DEFAULT NULL,
  `Username` varchar(7) DEFAULT NULL,
  `Usrtype` tinyint(4) DEFAULT NULL,
  `Password` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.Usuario`
--

LOCK TABLES `dbo.Usuario` WRITE;
/*!40000 ALTER TABLE `dbo.Usuario` DISABLE KEYS */;
INSERT INTO `dbo.Usuario` VALUES ('11111111-1','Alejandro','Soto','asotoz',0,'asoto2019'),('22222222-2','Miguel','Romero','mromero',1,'mromero2019'),('33333333-3','Benjamin','Mora','bmora',4,'bmora2019');
/*!40000 ALTER TABLE `dbo.Usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.__MigrationHistory`
--

DROP TABLE IF EXISTS `dbo.__MigrationHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.__MigrationHistory` (
  `MigrationId` varchar(29) DEFAULT NULL,
  `ContextKey` varchar(20) DEFAULT NULL,
  `Model` varchar(0) DEFAULT NULL,
  `ProductVersion` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.__MigrationHistory`
--

LOCK TABLES `dbo.__MigrationHistory` WRITE;
/*!40000 ALTER TABLE `dbo.__MigrationHistory` DISABLE KEYS */;
INSERT INTO `dbo.__MigrationHistory` VALUES ('201912200305119_InitialCreate','SALD.DAL.SALDContext','','6.4.0');
/*!40000 ALTER TABLE `dbo.__MigrationHistory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-22 15:20:26
